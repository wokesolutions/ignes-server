package com.wokesolutions.ignes.util;

public class Secrets {

	public static final String MAILGUN = "key-041696dd6c51a8d422ae874ede995256";
	public static final String JWTSECRET = "I only love Mahbed and my momma, I'm sorry.";
}
